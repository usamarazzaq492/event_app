@extends('layouts.app')

@section('title', 'Events - EventGo')

@push('styles')
<style>
.event-card {
  border-radius: 16px;
  background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);
  border: 1px solid rgba(77, 166, 255, 0.1);
  padding: 24px;
  display: flex;
  justify-content: space-between;
  align-items: center;
  box-shadow: 0 4px 20px rgba(13, 42, 86, 0.08);
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  min-height: 160px;
  margin-bottom: 16px;
}
.event-card:hover {
  transform: translateY(-6px);
  box-shadow: 0 12px 32px rgba(77, 166, 255, 0.2);
  border-color: rgba(77, 166, 255, 0.3);
}
.event-info {
  display: flex;
  align-items: center;
  gap: 20px;
  flex: 1;
}
.event-logo {
  flex-shrink: 0;
}
.event-logo img {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  object-fit: cover;
  background: #fff;
  padding: 8px;
  box-shadow: 0 4px 12px rgba(0,0,0,0.1);
  border: 2px solid rgba(77, 166, 255, 0.15);
}
.event-text h5 {
  margin: 0 0 8px 0;
  font-size: 1.15rem;
  font-weight: 700;
  color: #1f2937;
  line-height: 1.4;
}
.event-text .meta {
  font-size: 0.9rem;
  color: #6b7280;
  display: flex;
  flex-wrap: wrap;
  gap: 12px;
  align-items: center;
}
.event-text .meta i {
  color: #4da6ff;
}
.btn-apply {
  flex-shrink: 0;
  padding: 12px 24px;
  font-weight: 600;
  border-radius: 10px;
  transition: all 0.3s ease;
  box-shadow: 0 2px 8px rgba(77, 166, 255, 0.3);
}
.btn-apply:hover {
  transform: scale(1.05);
  box-shadow: 0 4px 16px rgba(77, 166, 255, 0.4);
}
.search-section {
  background: linear-gradient(135deg, rgba(79, 110, 247, 0.05) 0%, rgba(77, 166, 255, 0.05) 100%);
  padding: 40px 0;
  margin-bottom: 30px;
}
.search-section .input-group {
  max-width: 720px;
  margin: 0 auto;
  border-radius: 12px;
  overflow: hidden;
}
@media (max-width: 768px) {
  .event-card {
    flex-direction: column;
    text-align: center;
    min-height: auto;
    padding: 20px;
  }
  .event-info {
    flex-direction: column;
    gap: 15px;
  }
  .btn-apply {
    width: 100%;
    margin-top: 15px;
  }
}
</style>
@endpush

@section('content')
<!--Start Recent Event-->
<section class="section contact__v2" id="contact">
    <div class="container">
        <div class="row mb-5">
            <div class="col-md-6 col-lg-7 mt-4 mx-auto text-center">
                <span class="subtitle text-uppercase mb-3" data-aos="fade-up" data-aos-delay="0">Events</span>
                <h2 class="h2 fw-bold mb-3" data-aos="fade-up" data-aos-delay="0">Events</h2>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h3 class="mb-0">Upcoming Events</h3>
        </div>

        <div class="row">
            @foreach($recentEvents as $index => $recent)
            <div class="col-lg-3 col-md-6 mb-4" data-aos="fade-up" data-aos-delay="{{ 80 + ($index * 80) }}">
                <div class="event-card-modern">
                    <div class="position-relative">
                        @if($recent->eventImage)
                            <img src="{{ asset($recent->eventImage) }}" class="card-img" alt="{{ $recent->eventTitle }}"
                                onerror="this.onerror=null; this.src='https://via.placeholder.com/400x200/584CF4/ffffff?text={{ urlencode($recent->eventTitle) }}';">
                        @else
                            <img src="https://via.placeholder.com/400x200/584CF4/ffffff?text={{ urlencode($recent->eventTitle) }}"
                                class="card-img" alt="{{ $recent->eventTitle }}">
                        @endif
                        <div class="event-tag">{{ $recent->category ?? 'Event' }}</div>
                        <div class="event-attendees">{{ rand(50, 500) }}+</div>
                    </div>
                    <div class="card-body">
                        <h5 class="card-title">{{ Str::limit($recent->eventTitle, 40) }}</h5>
                        <div class="event-meta">
                            <div><i class="bi bi-calendar me-1"></i>{{ \Carbon\Carbon::parse($recent->startDate)->format('M d, Y') }}</div>
                            <div><i class="bi bi-geo-alt me-1"></i>{{ $recent->city ?? 'Location TBA' }}</div>
                        </div>
                        <a href="{{ route('events.show', $recent->eventId) }}" class="buy-now-btn">View Details</a>
                    </div>
                </div>
            </div>
            @endforeach
        </div>
    </div>
</section>
<!--End Recent Event-->

<!-- Search Bar -->
<section class="search-section">
    <div class="container">
        <form action="{{ route('events.search') }}" method="GET">
            <div class="input-group shadow-lg">
                <span class="input-group-text bg-white border-end-0 px-4">
                    <i class="fa fa-search text-primary"></i>
                </span>
                <input name="q" class="form-control form-control-lg border-start-0 border-end-0"
                    placeholder="Search events, categories, locations..."
                    aria-label="Search events"
                    value="{{ request('q') }}">
                <button class="btn btn-primary btn-lg px-5" type="submit">
                    <i class="fa fa-search me-2"></i>Search
                </button>
            </div>
        </form>
    </div>
</section>
<!-- End Search Bar -->

<!-- Event Cards -->
<div class="container pb-5">
    <div class="mb-4" data-aos="fade-up">
        <div class="d-flex justify-content-between align-items-center">
            <div>
                <h3 class="fw-bold mb-1">All Upcoming Events</h3>
                <p class="text-muted mb-0">{{ $events->total() }} upcoming events</p>
            </div>
            @auth
                <a href="{{ route('events.create') }}" class="btn btn-primary">
                    <i class="fas fa-plus me-2"></i>Create Event
                </a>
            @else
                <a href="{{ route('login') }}" class="btn btn-outline-primary">
                    <i class="fas fa-sign-in-alt me-2"></i>Login to Create Event
                </a>
            @endauth
        </div>
    </div>

    <div class="d-flex flex-column">
        @forelse($events as $event)
        <div class="event-card" data-aos="fade-up" data-aos-delay="{{ $loop->index * 50 }}">
            <div class="event-info">
                <div class="event-logo">
                    @if($event->eventImage)
                        <img src="{{ asset($event->eventImage) }}" alt="{{ $event->eventTitle }}"
                            onerror="this.onerror=null; this.src='https://via.placeholder.com/80/4da6ff/ffffff?text=Event';">
                    @else
                        <img src="https://via.placeholder.com/80/4da6ff/ffffff?text=Event" alt="{{ $event->eventTitle }}">
                    @endif
                </div>
                <div class="event-text">
                    <h5>{{ strtoupper($event->eventTitle) }}</h5>
                    <div class="meta">
                        <span><i class="bi bi-geo-alt-fill me-1"></i>{{ $event->city ?? 'Location TBA' }}</span>
                        <span>|</span>
                        <span><i class="bi bi-calendar-event me-1"></i>{{ \Carbon\Carbon::parse($event->startDate)->format('M d') }} - {{ \Carbon\Carbon::parse($event->endDate)->format('M d Y') }}</span>
                        @if($event->category)
                            <span>|</span>
                            <span><i class="bi bi-tag me-1"></i>{{ $event->category }}</span>
                        @endif
                    </div>
                </div>
            </div>
            <a href="{{ route('events.show', $event->eventId) }}" class="btn btn-primary btn-apply">
                <i class="bi bi-arrow-right-circle me-2"></i>View Details
            </a>
        </div>
        @empty
        <div class="text-center py-5" data-aos="fade-up">
            <i class="bi bi-calendar-x" style="font-size: 4rem; color: #cbd5e1;"></i>
            <h4 class="mt-3 text-muted">No Events Found</h4>
            <p class="text-muted">Try adjusting your search or explore all events</p>
            <div class="d-flex justify-content-center gap-3 mt-3">
                <a href="{{ route('events.index') }}" class="btn btn-outline-primary">
                    <i class="bi bi-arrow-clockwise me-2"></i>Show All Events
                </a>
                @auth
                    <a href="{{ route('events.create') }}" class="btn btn-primary">
                        <i class="fas fa-plus me-2"></i>Create Event
                    </a>
                @else
                    <a href="{{ route('login') }}" class="btn btn-primary">
                        <i class="fas fa-sign-in-alt me-2"></i>Login to Create Event
                    </a>
                @endauth
            </div>
        </div>
        @endforelse
    </div>

    <!-- Pagination -->
    @if($events->hasPages())
        <div class="mt-5 d-flex justify-content-center" data-aos="fade-up">
            {{ $events->links() }}
        </div>
    @endif
</div>
@endsection

@push('scripts')
<script>
    AOS.init({
        duration: 800,
        easing: 'ease-in-out',
        once: true
    });
</script>
@endpush
