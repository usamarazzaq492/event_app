@extends('layouts.app')

@section('title', 'Verify Email - EventGo')

@section('content')
<style>
:root {
  --primary-color: #584CF4;
  --secondary-color: #ff9500;
  --black: #000000;
  --white: #ffffff;
  --gray: #efefef;
  --gray-2: #757575;
}

@import url('https://fonts.googleapis.com/css2?family=Poppins:wght@200;300;400;500;600&display=swap');

* {
  font-family: 'Poppins', sans-serif;
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  background: #f8f9ff;
  min-height: 100vh;
  display: flex;
  align-items: center;
  justify-content: center;
}

.verify-container {
  background: white;
  border-radius: 20px;
  box-shadow: 0 10px 30px rgba(88, 76, 244, 0.1);
  padding: 40px;
  width: 100%;
  max-width: 500px;
  margin: 20px;
}

.verify-header {
  text-align: center;
  margin-bottom: 30px;
}

.verify-header h1 {
  color: var(--primary-color);
  font-size: 2rem;
  font-weight: 700;
  margin-bottom: 10px;
}

.verify-header p {
  color: var(--gray-2);
  font-size: 1rem;
  line-height: 1.6;
}

.verify-icon {
  width: 80px;
  height: 80px;
  background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  margin: 0 auto 20px;
  font-size: 2rem;
  color: white;
}

.verify-form {
  margin-top: 30px;
}

.input-group {
  position: relative;
  margin-bottom: 20px;
}

.input-group label {
  display: block;
  margin-bottom: 8px;
  color: var(--black);
  font-weight: 500;
  font-size: 0.9rem;
}

.input-group input {
  width: 100%;
  padding: 15px 20px;
  border: 2px solid #e1e5e9;
  border-radius: 12px;
  font-size: 1rem;
  transition: all 0.3s ease;
  background: white;
}

.input-group input:focus {
  outline: none;
  border-color: var(--primary-color);
  box-shadow: 0 0 0 3px rgba(88, 76, 244, 0.1);
}

.verify-btn {
  width: 100%;
  background: linear-gradient(135deg, var(--primary-color), var(--secondary-color));
  color: white;
  border: none;
  padding: 15px;
  border-radius: 12px;
  font-size: 1rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s ease;
  margin-top: 10px;
}

.verify-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 8px 25px rgba(88, 76, 244, 0.3);
}

.verify-btn:disabled {
  opacity: 0.7;
  cursor: not-allowed;
  transform: none;
}

.back-link {
  text-align: center;
  margin-top: 20px;
}

.back-link a {
  color: var(--primary-color);
  text-decoration: none;
  font-weight: 500;
  transition: color 0.3s ease;
}

.back-link a:hover {
  color: var(--secondary-color);
}

.error-message {
  background: #fee;
  color: #c53030;
  padding: 12px 15px;
  border-radius: 8px;
  margin-bottom: 20px;
  border-left: 4px solid #c53030;
  font-size: 0.9rem;
}

.success-message {
  background: #f0fff4;
  color: #2d7d32;
  padding: 12px 15px;
  border-radius: 8px;
  margin-bottom: 20px;
  border-left: 4px solid #2d7d32;
  font-size: 0.9rem;
}

@media (max-width: 768px) {
  .verify-container {
    margin: 10px;
    padding: 30px 20px;
  }

  .verify-header h1 {
    font-size: 1.5rem;
  }

  .verify-icon {
    width: 60px;
    height: 60px;
    font-size: 1.5rem;
  }
}
</style>

<div class="verify-container">
    <div class="verify-header">
        <div class="verify-icon">
            📧
        </div>
        <h1>Verify Your Email</h1>
        <p>We've sent a verification code to your email address. Please enter the code below to complete your registration.</p>
    </div>

    @if ($errors->any())
        <div class="error-message">
            @foreach ($errors->all() as $error)
                <div>{{ $error }}</div>
            @endforeach
        </div>
    @endif

    @if (session('info'))
        <div class="success-message">
            {{ session('info') }}
        </div>
    @endif

    <form class="verify-form" method="POST" action="{{ route('verify.email.submit') }}">
        @csrf

        <div class="input-group">
            <label for="email">Email Address</label>
            <input type="email" id="email" name="email" value="{{ old('email') }}" required>
        </div>

        <div class="input-group">
            <label for="verificationCode">Verification Code</label>
            <input type="number" id="verificationCode" name="verificationCode" value="{{ old('verificationCode') }}" placeholder="Enter 4-digit code" required>
        </div>

        <button type="submit" class="verify-btn">
            Verify Email
        </button>
    </form>

    <div class="back-link">
        <a href="{{ route('login') }}">← Back to Login</a>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Auto-focus on verification code input
    const codeInput = document.getElementById('verificationCode');
    if (codeInput) {
        codeInput.focus();
    }

    // Limit verification code to 4 digits
    codeInput.addEventListener('input', function(e) {
        if (e.target.value.length > 4) {
            e.target.value = e.target.value.slice(0, 4);
        }
    });
});
</script>
@endsection
