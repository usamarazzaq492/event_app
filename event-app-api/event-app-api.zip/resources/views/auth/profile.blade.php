@extends('layouts.app')

@section('title', 'Profile - EventGo')

@section('content')
<div class="container py-5">
    <div class="row justify-content-center">
        <div class="col-lg-8">
            <!-- Profile Header -->
            <div class="profile-header text-center mb-5" data-aos="fade-up">
                <div class="profile-avatar mb-3">
                    @if(Auth::user()->profileImageUrl)
                        <img src="{{ asset(Auth::user()->profileImageUrl) }}"
                             alt="{{ Auth::user()->name }}"
                             class="profile-image-large">
                    @else
                        <div class="profile-image-placeholder-large">
                            <i class="fas fa-user"></i>
                        </div>
                    @endif
                </div>
                <h2 class="profile-name">{{ Auth::user()->name }}</h2>
                <p class="profile-email text-muted">{{ Auth::user()->email }}</p>
                <div class="profile-status">
                    @if(Auth::user()->emailVerified == 1)
                        <span class="badge bg-success">
                            <i class="fas fa-check-circle me-1"></i>Email Verified
                        </span>
                    @else
                        <span class="badge bg-warning">
                            <i class="fas fa-exclamation-triangle me-1"></i>Email Not Verified
                        </span>
                    @endif
                    @if(Auth::user()->isActive == 1)
                        <span class="badge bg-primary ms-2">
                            <i class="fas fa-user-check me-1"></i>Active
                        </span>
                    @else
                        <span class="badge bg-danger ms-2">
                            <i class="fas fa-user-times me-1"></i>Inactive
                        </span>
                    @endif
                </div>
            </div>

            <!-- Profile Tabs -->
            <div class="profile-tabs" data-aos="fade-up" data-aos-delay="100">
                <ul class="nav nav-tabs" id="profileTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="info-tab" data-bs-toggle="tab" data-bs-target="#info" type="button" role="tab">
                            <i class="fas fa-user me-2"></i>Personal Info
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="events-tab" data-bs-toggle="tab" data-bs-target="#events" type="button" role="tab">
                            <i class="fas fa-calendar me-2"></i>My Events
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="bookings-tab" data-bs-toggle="tab" data-bs-target="#bookings" type="button" role="tab">
                            <i class="fas fa-ticket-alt me-2"></i>My Bookings
                        </button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="ads-tab" data-bs-toggle="tab" data-bs-target="#ads" type="button" role="tab">
                            <i class="fas fa-bullhorn me-2"></i>My Ads
                        </button>
                    </li>
                </ul>

                <div class="tab-content" id="profileTabsContent">
                    <!-- Personal Info Tab -->
                    <div class="tab-pane fade show active" id="info" role="tabpanel">
                        <div class="card border-0 shadow-sm mt-3">
                            <div class="card-header bg-white">
                                <h5 class="mb-0">
                                    <i class="fas fa-edit me-2"></i>Edit Profile Information
                                </h5>
                            </div>
                            <div class="card-body">
                                <form method="POST" action="{{ route('profile') }}" enctype="multipart/form-data">
                                    @csrf
                                    @method('PUT')

                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="name" class="form-label">Full Name</label>
                                            <input type="text" class="form-control @error('name') is-invalid @enderror"
                                                   id="name" name="name" value="{{ old('name', Auth::user()->name) }}" required>
                                            @error('name')
                                                <div class="invalid-feedback">{{ $error }}</div>
                                            @enderror
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label for="email" class="form-label">Email Address</label>
                                            <input type="email" class="form-control @error('email') is-invalid @enderror"
                                                   id="email" name="email" value="{{ old('email', Auth::user()->email) }}" required>
                                            @error('email')
                                                <div class="invalid-feedback">{{ $error }}</div>
                                            @enderror
                                        </div>
                                    </div>

                                    <div class="row">
                                        <div class="col-md-6 mb-3">
                                            <label for="phone" class="form-label">Phone Number</label>
                                            <input type="tel" class="form-control @error('phone') is-invalid @enderror"
                                                   id="phone" name="phone" value="{{ old('phone', Auth::user()->phoneNumber) }}">
                                            @error('phone')
                                                <div class="invalid-feedback">{{ $error }}</div>
                                            @enderror
                                        </div>
                                        <div class="col-md-6 mb-3">
                                            <label for="profile_image" class="form-label">Profile Image</label>
                                            <input type="file" class="form-control @error('profile_image') is-invalid @enderror"
                                                   id="profile_image" name="profile_image" accept="image/*">
                                            @error('profile_image')
                                                <div class="invalid-feedback">{{ $error }}</div>
                                            @enderror
                                            <small class="form-text text-muted">Max size: 2MB. Supported formats: JPG, PNG, GIF</small>
                                        </div>
                                    </div>

                                    <div class="mb-3">
                                        <label for="shortBio" class="form-label">Bio</label>
                                        <textarea class="form-control @error('shortBio') is-invalid @enderror"
                                                  id="shortBio" name="shortBio" rows="3"
                                                  placeholder="Tell us about yourself...">{{ old('shortBio', Auth::user()->shortBio) }}</textarea>
                                        @error('shortBio')
                                            <div class="invalid-feedback">{{ $error }}</div>
                                        @enderror
                                    </div>

                                    <div class="mb-3">
                                        <label class="form-label">Interests</label>
                                        <div class="row">
                                            @php
                                                $interests = ['Music', 'Sports', 'Technology', 'Art', 'Food', 'Travel', 'Education', 'Business', 'Health', 'Entertainment'];
                                                $userInterests = Auth::user()->interests ?? [];
                                            @endphp
                                            @foreach($interests as $interest)
                                                <div class="col-md-4 col-sm-6 mb-2">
                                                    <div class="form-check">
                                                        <input class="form-check-input" type="checkbox"
                                                               name="interests[]" value="{{ $interest }}"
                                                               id="interest_{{ $loop->index }}"
                                                               {{ in_array($interest, $userInterests) ? 'checked' : '' }}>
                                                        <label class="form-check-label" for="interest_{{ $loop->index }}">
                                                            {{ $interest }}
                                                        </label>
                                                    </div>
                                                </div>
                                            @endforeach
                                        </div>
                                    </div>

                                    <div class="d-flex justify-content-between">
                                        <button type="submit" class="btn btn-primary">
                                            <i class="fas fa-save me-2"></i>Update Profile
                                        </button>
                                        <a href="{{ route('home') }}" class="btn btn-outline-secondary">
                                            <i class="fas fa-arrow-left me-2"></i>Back to Home
                                        </a>
                                    </div>
                                </form>
                            </div>
                        </div>

                        <!-- Change Password Section -->
                        <div class="card border-0 shadow-sm mt-4">
                            <div class="card-header bg-white">
                                <h5 class="mb-0">
                                    <i class="fas fa-lock me-2"></i>Change Password
                                </h5>
                            </div>
                            <div class="card-body">
                                <form method="POST" action="{{ route('profile.password') }}">
                                    @csrf

                                    <div class="row">
                                        <div class="col-md-4 mb-3">
                                            <label for="current_password" class="form-label">Current Password</label>
                                            <input type="password" class="form-control @error('current_password') is-invalid @enderror"
                                                   id="current_password" name="current_password" required>
                                            @error('current_password')
                                                <div class="invalid-feedback">{{ $error }}</div>
                                            @enderror
                                        </div>
                                        <div class="col-md-4 mb-3">
                                            <label for="new_password" class="form-label">New Password</label>
                                            <input type="password" class="form-control @error('new_password') is-invalid @enderror"
                                                   id="new_password" name="new_password" required>
                                            @error('new_password')
                                                <div class="invalid-feedback">{{ $error }}</div>
                                            @enderror
                                        </div>
                                        <div class="col-md-4 mb-3">
                                            <label for="new_password_confirmation" class="form-label">Confirm New Password</label>
                                            <input type="password" class="form-control @error('new_password_confirmation') is-invalid @enderror"
                                                   id="new_password_confirmation" name="new_password_confirmation" required>
                                            @error('new_password_confirmation')
                                                <div class="invalid-feedback">{{ $error }}</div>
                                            @enderror
                                        </div>
                                    </div>

                                    <div style="font-size: 0.75rem; color: #666; margin-bottom: 1rem; padding: 0.5rem; background: #f8f9ff; border-radius: 5px;">
                                        <strong>Password Requirements:</strong><br>
                                        • At least 8 characters<br>
                                        • Uppercase letter (A-Z)<br>
                                        • Lowercase letter (a-z)<br>
                                        • Number (0-9)<br>
                                        • Special character (@$!%*#?&)
                                    </div>

                                    <button type="submit" class="btn btn-warning">
                                        <i class="fas fa-key me-2"></i>Change Password
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>

                    <!-- My Events Tab -->
                    <div class="tab-pane fade" id="events" role="tabpanel">
                        <div class="card border-0 shadow-sm mt-3">
                            <div class="card-header bg-white">
                                <h5 class="mb-0">
                                    <i class="fas fa-calendar me-2"></i>Events Created by You
                                </h5>
                            </div>
                            <div class="card-body">
                                <div class="text-center text-muted py-5">
                                    <i class="fas fa-calendar-plus fa-3x mb-3"></i>
                                    <h5>No events created yet</h5>
                                    <p>Start creating amazing events for your community!</p>
                                    <a href="{{ route('events.create') }}" class="btn btn-primary">
                                        <i class="fas fa-plus me-2"></i>Create Your First Event
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- My Bookings Tab -->
                    <div class="tab-pane fade" id="bookings" role="tabpanel">
                        <div class="card border-0 shadow-sm mt-3">
                            <div class="card-header bg-white">
                                <h5 class="mb-0">
                                    <i class="fas fa-ticket-alt me-2"></i>Your Event Bookings
                                </h5>
                            </div>
                            <div class="card-body">
                                <div class="text-center text-muted py-5">
                                    <i class="fas fa-ticket-alt fa-3x mb-3"></i>
                                    <h5>No bookings yet</h5>
                                    <p>Discover and book amazing events!</p>
                                    <a href="{{ route('events.index') }}" class="btn btn-primary">
                                        <i class="fas fa-search me-2"></i>Browse Events
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>

                    <!-- My Ads Tab -->
                    <div class="tab-pane fade" id="ads" role="tabpanel">
                        <div class="card border-0 shadow-sm mt-3">
                            <div class="card-header bg-white d-flex justify-content-between align-items-center">
                                <h5 class="mb-0">
                                    <i class="fas fa-bullhorn me-2"></i>Your Campaigns
                                </h5>
                            </div>
                            <div class="card-body">
                                @php
                                    $userAds = DB::table('donation')
                                        ->where('userId', Auth::id())
                                        ->orderBy('addDate', 'desc')
                                        ->get();
                                @endphp

                                @if($userAds->count() > 0)
                                    <div class="row">
                                        @foreach($userAds as $ad)
                                            @php
                                                $totalRaised = DB::table('donation_transactions')
                                                    ->where('donationId', $ad->donationId)
                                                    ->sum('amount');
                                                $donationCount = DB::table('donation_transactions')
                                                    ->where('donationId', $ad->donationId)
                                                    ->count();
                                                $progress = $ad->amount > 0 ? min(($totalRaised / $ad->amount) * 100, 100) : 0;
                                            @endphp

                                            <div class="col-md-6 mb-3">
                                                <div class="card border-0 shadow-sm h-100">
                                                    <div class="position-relative">
                                                        @if($ad->imageUrl)
                                                            <img src="{{ asset($ad->imageUrl) }}"
                                                                 class="card-img-top"
                                                                 alt="{{ $ad->title }}"
                                                                 style="height: 150px; object-fit: cover;">
                                                        @else
                                                            <div class="card-img-top bg-light d-flex align-items-center justify-content-center"
                                                                 style="height: 150px;">
                                                                <i class="fas fa-image fa-2x text-muted"></i>
                                                            </div>
                                                        @endif
                                                        <div class="position-absolute top-0 end-0 m-2">
                                                            @if($ad->isActive == 1)
                                                                <span class="badge bg-success">Active</span>
                                                            @else
                                                                <span class="badge bg-secondary">Inactive</span>
                                                            @endif
                                                        </div>
                                                    </div>

                                                    <div class="card-body d-flex flex-column">
                                                        <h6 class="card-title fw-bold">{{ $ad->title }}</h6>
                                                        <p class="card-text text-muted small flex-grow-1">
                                                            {{ Str::limit($ad->description, 80) }}
                                                        </p>

                                                        <div class="mt-auto">
                                                            <!-- Progress -->
                                                            <div class="mb-2">
                                                                <div class="d-flex justify-content-between mb-1">
                                                                    <small class="text-muted">Progress</small>
                                                                    <small class="text-muted">{{ number_format($progress, 1) }}%</small>
                                                                </div>
                                                                <div class="progress" style="height: 6px;">
                                                                    <div class="progress-bar bg-primary"
                                                                         style="width: {{ $progress }}%"></div>
                                                                </div>
                                                            </div>

                                                            <!-- Stats -->
                                                            <div class="row text-center mb-2">
                                                                <div class="col-4">
                                                                    <h6 class="fw-bold text-primary mb-0 small">${{ number_format($totalRaised, 0) }}</h6>
                                                                    <small class="text-muted">Raised</small>
                                                                </div>
                                                                <div class="col-4">
                                                                    <h6 class="fw-bold text-warning mb-0 small">${{ number_format($ad->amount, 0) }}</h6>
                                                                    <small class="text-muted">Goal</small>
                                                                </div>
                                                                <div class="col-4">
                                                                    <h6 class="fw-bold text-success mb-0 small">{{ $donationCount }}</h6>
                                                                    <small class="text-muted">Donors</small>
                                                                </div>
                                                            </div>

                                                            <!-- Actions -->
                                                            <div class="d-flex gap-1">
                                                                <a href="{{ route('ads.show', $ad->donationId) }}"
                                                                   class="btn btn-outline-primary btn-sm flex-grow-1">
                                                                    <i class="fas fa-eye"></i>
                                                                </a>
                                                                <a href="{{ route('ads.edit', $ad->donationId) }}"
                                                                   class="btn btn-outline-secondary btn-sm">
                                                                    <i class="fas fa-edit"></i>
                                                                </a>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        @endforeach
                                    </div>
                                @else
                                    <div class="text-center text-muted py-5">
                                        <i class="fas fa-bullhorn fa-3x mb-3"></i>
                                        <h5>No campaigns yet</h5>
                                        <p>Start your first fundraising campaign!</p>
                                        <a href="{{ route('ads.create') }}" class="btn btn-primary">
                                            <i class="fas fa-plus me-2"></i>Create Your First Campaign
                                        </a>
                                    </div>
                                @endif
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<style>
.profile-header {
    background: white;
    border-radius: 20px;
    padding: 2rem;
    box-shadow: 0 8px 32px rgba(0, 0, 0, 0.1);
}

.profile-avatar {
    position: relative;
    display: inline-block;
}

.profile-image-large {
    width: 120px;
    height: 120px;
    border-radius: 50%;
    object-fit: cover;
    border: 4px solid #584CF4;
    box-shadow: 0 8px 32px rgba(88, 76, 244, 0.3);
}

.profile-image-placeholder-large {
    width: 120px;
    height: 120px;
    border-radius: 50%;
    background: #584CF4;
    display: flex;
    align-items: center;
    justify-content: center;
    color: white;
    font-size: 48px;
    border: 4px solid #584CF4;
    box-shadow: 0 8px 32px rgba(88, 76, 244, 0.3);
}

.profile-name {
    color: #2c2c2c;
    font-weight: 700;
    margin-bottom: 0.5rem;
}

.profile-email {
    font-size: 1.1rem;
    margin-bottom: 1rem;
}

.profile-tabs .nav-tabs {
    border-bottom: 2px solid #e9ecef;
}

.profile-tabs .nav-tabs .nav-link {
    border: none;
    color: #6c757d;
    font-weight: 500;
    padding: 1rem 1.5rem;
    border-radius: 0;
    transition: all 0.3s ease;
}

.profile-tabs .nav-tabs .nav-link:hover {
    color: #584CF4;
    background: #f8f9ff;
}

.profile-tabs .nav-tabs .nav-link.active {
    color: #584CF4;
    background: #f8f9ff;
    border-bottom: 2px solid #584CF4;
}

.card {
    border-radius: 15px;
    transition: all 0.3s ease;
}

.card:hover {
    transform: translateY(-2px);
    box-shadow: 0 12px 40px rgba(0, 0, 0, 0.15) !important;
}

.form-control:focus {
    border-color: #584CF4;
    box-shadow: 0 0 0 0.2rem rgba(88, 76, 244, 0.25);
}

.btn-primary {
    background: #584CF4;
    border-color: #584CF4;
}

.btn-primary:hover {
    background: #4a3dd1;
    border-color: #4a3dd1;
}

.btn-warning {
    background: #ff9500;
    border-color: #ff9500;
}

.btn-warning:hover {
    background: #e6850e;
    border-color: #e6850e;
}

.badge {
    font-size: 0.8rem;
    padding: 0.5rem 0.8rem;
}

@media (max-width: 768px) {
    .profile-header {
        padding: 1.5rem;
    }

    .profile-image-large,
    .profile-image-placeholder-large {
        width: 80px;
        height: 80px;
        font-size: 32px;
    }

    .profile-tabs .nav-tabs .nav-link {
        padding: 0.8rem 1rem;
        font-size: 0.9rem;
    }
}
</style>
@endsection
