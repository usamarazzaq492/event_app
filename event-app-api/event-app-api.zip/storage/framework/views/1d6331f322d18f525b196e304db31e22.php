<?php $__env->startSection('title', $event->eventTitle . ' - EventGo'); ?>

<?php $__env->startPush('styles'); ?>
<style>
:root {
    --primary: #4da6ff;
    --primary-dark: #247fd9;
    --bg: #ffffff;
    --muted: #6b7280;
    --card-shadow: 0 10px 20px rgba(13, 42, 86, 0.06);
}

.feature-card {
    border-radius: 12px;
    box-shadow: var(--card-shadow);
    transition: transform .22s cubic-bezier(.2, .9, .3, 1), box-shadow .22s;
    background: var(--bg);
    padding: 1.25rem;
    min-height: 180px;
}

.feature-card:hover {
    transform: translateY(-8px);
    box-shadow: 0 18px 40px rgba(13, 42, 86, 0.12);
}

.feature-icon {
    width: 56px;
    height: 56px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 12px;
    color: white;
    margin-bottom: .75rem;
    font-size: 1.2rem;
}

.banner {
    position: relative;
    border-radius: 16px;
    overflow: hidden;
}

.banner img {
    width: 100%;
    height: 250px;
    object-fit: cover;
}

.banner-title {
    position: absolute;
    bottom: 20px;
    left: 20px;
    color: #fff;
    background: rgba(0, 0, 0, 0.5);
    padding: 10px 20px;
    border-radius: 12px;
}

.banner-title h3 {
    margin: 0;
}

.rating i {
    color: #f59e0b;
    font-size: 1.2rem;
}

.rating i.text-muted {
    color: #ccc;
}
</style>
<?php $__env->stopPush(); ?>

<?php $__env->startSection('content'); ?>
<!-- Event Detail -->
<section class="section contact__v2" id="contact">
    <div class="container py-4">

        <!-- Banner -->
        <div class="banner mb-4">
            <?php if($event->eventImage): ?>
                <img src="<?php echo e(asset($event->eventImage)); ?>" alt="<?php echo e($event->eventTitle); ?>"
                    onerror="this.onerror=null; this.src='https://via.placeholder.com/1200x250/4da6ff/ffffff?text=<?php echo e(urlencode($event->eventTitle)); ?>';">
            <?php else: ?>
                <img src="https://via.placeholder.com/1200x250/4da6ff/ffffff?text=<?php echo e(urlencode($event->eventTitle)); ?>"
                    alt="<?php echo e($event->eventTitle); ?>">
            <?php endif; ?>
            <div class="banner-title">
                <h3><?php echo e($event->eventTitle); ?></h3>
                <p><?php echo e($event->category ?? 'Event'); ?> <?php echo e(\Carbon\Carbon::parse($event->startDate)->format('Y')); ?></p>
            </div>
        </div>

        <div class="row g-4">
            <!-- Left Info -->
            <div class="col-lg-8">
                <div class="feature-card d-flex gap-3 align-items-start">
                    <?php if($event->eventImage): ?>
                        <img src="<?php echo e(asset($event->eventImage)); ?>"
                            class="rounded-circle bg-light p-2" alt="Logo" width="120" height="120"
                            onerror="this.onerror=null; this.src='https://via.placeholder.com/120/4da6ff/ffffff?text=Event';">
                    <?php else: ?>
                        <img src="https://via.placeholder.com/120/4da6ff/ffffff?text=Event"
                            class="rounded-circle bg-light p-2" alt="Logo" width="120" height="120">
                    <?php endif; ?>
                    <div>
                        <h5 class="mb-2">Applications</h5>
                        <p class="mb-1"><i class="bi bi-geo-alt-fill"></i> <?php echo e($event->city ?? 'Location TBA'); ?></p>
                        <p class="mb-1">
                            <i class="bi bi-calendar-event"></i>
                            <?php echo e(\Carbon\Carbon::parse($event->startDate)->format('M d')); ?> -
                            <?php echo e(\Carbon\Carbon::parse($event->endDate)->format('M d Y')); ?>

                        </p>
                        <?php if($event->category): ?>
                            <p class="mb-1"><i class="bi bi-mortarboard-fill"></i> <?php echo e($event->category); ?></p>
                        <?php endif; ?>
                        <?php if($event->bookings && $event->bookings->count() > 0): ?>
                            <p class="mb-1"><i class="bi bi-people-fill"></i> <?php echo e($event->bookings->count()); ?> Expected Delegates</p>
                        <?php endif; ?>
                        <div class="d-flex gap-2 mt-2">
                            <a href="https://instagram.com" target="_blank"
                                class="btn btn-outline-primary btn-sm"><i class="bi bi-instagram"></i></a>
                            <a href="mailto:info@eventgo.com" class="btn btn-outline-primary btn-sm"><i
                                    class="bi bi-envelope"></i></a>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Right Apply -->
            <div class="col-lg-4">
                <div class="feature-card text-center">
                    <h5>Apply Now!</h5>
                    <?php if($event->eventPrice > 0): ?>
                        <p class="small">Price: $<?php echo e(number_format($event->eventPrice, 2)); ?></p>
                    <?php else: ?>
                        <p class="small">Free Event</p>
                    <?php endif; ?>
                    <?php if(auth()->guard()->check()): ?>
                        <form action="<?php echo e(route('events.book', $event->eventId)); ?>" method="POST">
                            <?php echo csrf_field(); ?>

                            <?php if($event->eventPrice > 0): ?>
                                <div class="mb-3">
                                    <label class="form-label small">Ticket Type</label>
                                    <select name="ticket_type" class="form-select form-select-sm" required>
                                        <option value="general">General - $<?php echo e(number_format($event->eventPrice, 2)); ?></option>
                                        <option value="silver">Silver - $<?php echo e(number_format($event->eventPrice * 1.2, 2)); ?></option>
                                        <option value="gold">Gold - $<?php echo e(number_format($event->eventPrice * 1.5, 2)); ?></option>
                                    </select>
                                </div>

                                <div class="mb-3">
                                    <label class="form-label small">Quantity</label>
                                    <select name="quantity" class="form-select form-select-sm" required>
                                        <?php for($i = 1; $i <= 10; $i++): ?>
                                            <option value="<?php echo e($i); ?>"><?php echo e($i); ?> <?php echo e($i == 1 ? 'ticket' : 'tickets'); ?></option>
                                        <?php endfor; ?>
                                    </select>
                                </div>
                            <?php else: ?>
                                <input type="hidden" name="ticket_type" value="general">
                                <input type="hidden" name="quantity" value="1">
                            <?php endif; ?>

                            <button type="submit" class="btn btn-primary btn-sm w-100">
                                <?php if($event->eventPrice > 0): ?>
                                    Book Now! <i class="bi bi-arrow-right"></i>
                                <?php else: ?>
                                    Register Now! <i class="bi bi-arrow-right"></i>
                                <?php endif; ?>
                            </button>
                        </form>
                    <?php else: ?>
                        <a href="<?php echo e(route('login')); ?>" class="btn btn-primary btn-sm w-100">
                            Login to Book <i class="bi bi-arrow-right"></i>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        </div>

        <!-- Inspire Section -->
        <div class="col-md-12 aos-init aos-animate" data-aos="fade-up" data-aos-delay="80">
            <div class="feature-card my-4">
                <h5><?php echo e($event->eventTitle); ?></h5>
                <p style="white-space: pre-wrap;"><?php echo e($event->description); ?></p>
            </div>
        </div>

        <!-- Reviews -->
        <div class="col-md-12 aos-init aos-animate" data-aos="fade-up" data-aos-delay="80">
            <div class="feature-card">
                <h5>Reviews</h5>
                <div class="rating my-2">
                    <i class="bi bi-star-fill"></i>
                    <i class="bi bi-star-fill"></i>
                    <i class="bi bi-star-fill"></i>
                    <i class="bi bi-star-half"></i>
                    <i class="bi bi-star text-muted"></i>
                </div>
                <p class="mb-0">
                    After the conference, participants will be asked to leave a review. Once the first
                    one comes in, you will see it here.
                </p>
            </div>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    AOS.init({
        duration: 800,
        easing: 'ease-in-out',
        once: true
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\event_app_workspace\event-app-api\resources\views/events/show.blade.php ENDPATH**/ ?>