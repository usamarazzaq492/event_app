<!-- Top Bar -->

<!-- Modern Header -->
<header class="modern-header">
    <div class="container">
        <nav class="navbar navbar-expand-lg">
            <div class="container-fluid">
                <!-- Logo -->
                <a href="<?php echo e(route('home')); ?>" class="navbar-brand">
                    <img src="<?php echo e(asset('assets/images/logo.png')); ?>" alt="EventGo" style="height: 50px;" />
                </a>

                <!-- Mobile toggle -->
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <!-- Navigation -->
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav mx-auto modern-nav">
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('home')); ?>">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('events.index')); ?>">Events</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('ads.index')); ?>">Ads</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('about')); ?>">About</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('contact')); ?>">Contact</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route('faq')); ?>">FAQ</a>
                        </li>
                    </ul>

                    <!-- Right side -->
                    <div class="d-flex align-items-center gap-3">
                        <?php if(auth()->guard()->check()): ?>
                            <a href="<?php echo e(route('events.create')); ?>" class="create-event-btn">Create Event</a>
                            <a href="<?php echo e(route('profile')); ?>" class="user-profile-link">
                                <div class="user-avatar">
                                    <?php if(Auth::user()->profileImageUrl): ?>
                                        <img src="<?php echo e(asset(Auth::user()->profileImageUrl)); ?>"
                                             alt="<?php echo e(Auth::user()->name); ?>"
                                             class="profile-image">
                                    <?php else: ?>
                                        <div class="profile-image-placeholder">
                                            <i class="fas fa-user"></i>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </a>
                        <?php else: ?>
                            <a href="<?php echo e(route('login')); ?>" class="btn btn-outline-primary rounded-pill">Login</a>
                            <a href="<?php echo e(route('events.create')); ?>" class="create-event-btn">Create Event</a>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </nav>
    </div>
</header>
<?php /**PATH C:\event_app_workspace\event-app-api\resources\views/layouts/partials/header.blade.php ENDPATH**/ ?>